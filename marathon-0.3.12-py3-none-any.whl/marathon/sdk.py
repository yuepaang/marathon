from __future__ import annotations
import websockets
import logging
import json
import abc
import sys
import os
import asyncio
from transitions import MachineError
from transitions.extensions import GraphMachine
from typing import Dict
from enum import Enum, unique
import datetime


log_format = "%(asctime)s - %(levelname)s - %(message)s"
logging.getLogger("transitions").setLevel(logging.INFO)

logger = logging.getLogger("ALGOSDK")
logger.setLevel(logging.DEBUG)
sh = logging.StreamHandler(stream=sys.stdout)
sh.setFormatter(logging.Formatter(log_format))
logger.addHandler(sh)

class Agent(dict):
    def __init__(self,data):
        self.walls = []
        for w in data['walls']:
            #check key exist
            if 'x' in w.keys() and 'y' in w.keys():
                self.walls.append(Wall(w['x'],w['y']))
        self.portals = []
        for p in data['portals']:
            if 'x' in p.keys() and 'y' in p.keys() and 'pair' in p.keys():
                self.portals.append(Portal(p['x'],p['y'],p['pair']))
        self.coins = []
        for c in data['coins']:
            if 'x' in c.keys() and 'y' in c.keys() and 'score' in c.keys():
                self.coins.append(Coin(c['x'],c['y'],c['score']))
        self.powerups = []
        for p in data["powerups"]:
            if 'x' in p.keys() and 'y' in p.keys() and 'powerup' in p.keys():
                self.powerups.append(Powerup(p['x'],p['y'],p['powerup']))

        self.other_agents = []
        for a in data["other_agents"]:
            if a:
                self.other_agents.append(AgentDef(**a))

        if data["self_agent"]:
            self.self_agent = AgentDef(**data["self_agent"])

    def get_pos(self) -> dict:
        return self.self_agent.get_pos()
    
    def get_role(self) -> str:
        return self.self_agent.get_role()
    
    def get_other_agents(self) -> list:
        return self.other_agents
    
    def get_walls(self) -> list:
        return self.walls
    
    def get_portals(self) -> list:
        return self.portals
    
    def get_coins(self) -> list:
        return self.coins
    
    def get_powerups(self) -> list:
        return self.powerups
    
    def get_self_agent(self) -> AgentDef:
        return self.self_agent
    
    def __str__(self):
        return json.dumps(self.__dict__, default=lambda o: o.__dict__, sort_keys=True)

    
    def __getitem__(self, key):     # 获取key对应的value
        return self.__dict__.get(key)


    def __repr__(self):
        return str(self)



class AgentDef():
    def __init__(self, 
        x: int,y: int, id: int, powerups: list,
        role: str, player_id: str, 
        vision_range: int, score: int, 
        invulnerability_duration: int):
        self.x = x
        self.y = y
        self.id = id
        self.powerups = powerups
        self.role = role
        self.player_id = player_id
        self.vision_range = vision_range
        self.score = score
        self.invulnerability_duration = invulnerability_duration
        self.__dict__ = {
            "x":x,
            "y":y,
            "id":id,
            "powerups": powerups,
            "role": role,
            "player_id": player_id,
            "vision_range": vision_range,
            "score": score,
            "invulnerability_duration": invulnerability_duration
        }

    def get_pos(self) -> dict:
        return {"x":self.x,"y":self.y}
    
    def get_role(self) -> str:
        return self.role
    
    def get_player_id(self) -> str:
        return self.player_id
    
    def get_vision_range(self) -> int:
        return self.vision_range
    
    def get_score(self) -> int:
        return self.score
    
    def get_invulnerability_duration(self) -> int:
        return self.invulnerability_duration
    
    def get_powerups(self) -> list:
        return self.powerups
    
    def to_json(self):
        return json.dumps(self, default=lambda o: o.__dict__, sort_keys=True)
    
    def __str__(self):
        return json.dumps(self.__dict__, default=lambda o: o.__dict__, sort_keys=True)
    
    def __repr__(self) -> str:
        return str(self)
    
    def __getitem__(self, key):
        return self.__dict__.get(key)

class Wall():
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.__dict__ = {
            "x":x,
            "y":y
        }
    
    def __getitem__(self, key):     # 获取key对应的value
        return self.__dict__.get(key)
    
    def __str__(self):
        return json.dumps(self.__dict__, default=lambda o: o.__dict__, sort_keys=True)
    
    def __repr__(self) -> str:
        return str(self)
  

class Portal():
    def __init__(self, x, y, pair):
        self.x = x
        self.y = y
        self.pair = pair
        self.__dict__ = {
            "x":x,
            "y":y,
            "pair": pair
        }
    
    def __getitem__(self, key):     # 获取key对应的value
        return self.__dict__.get(key)

    def __str__(self):
        return json.dumps(self.__dict__, default=lambda o: o.__dict__, sort_keys=True)
    
    def __repr__(self) -> str:
        return str(self)

class Coin():
    def __init__(self, x, y, score):
        self.x = x
        self.y = y
        self.score = score
        self.__dict__ = {
            "x":x,
            "y":y,
            "score": score
        }
    
    def __getitem__(self, key):     # 获取key对应的value
        return self.__dict__.get(key)

    def __str__(self):
        return json.dumps(self.__dict__, default=lambda o: o.__dict__, sort_keys=True)

    def __repr__(self) -> str:
        return str(self)

class Powerup(dict):
    def __init__(self, x, y, powerup):
        self.x = x
        self.y = y
        self.powerup = powerup
        self.__dict__ = {
            "x":x,
            "y":y,
            "powerup": powerup
        }

    def __getitem__(self, key):     # 获取key对应的value
        return self.__dict__.get(key)

    def __str__(self):
        return json.dumps(self.__dict__, default=lambda o: o.__dict__, sort_keys=True)

    def __repr__(self) -> str:
        return str(self)

class MessageGameState(object):
    def __init__(self,data=None):
        self.type = "state"
        self.steps = 0
        self.states = {}
        if data is not None:
            for k,v in data.items():
                if k == "states":
                    for _k,_v in v.items():
                        self.states[_k] = Agent(_v)
                else:
                    setattr(self,k,v)
    
    def get_steps(self) -> int:
        return self.steps
    
    def get_states(self) -> Dict[str,Agent]:
        return self.states
    
    def __getitem__(self, key):     # 获取key对应的value
        return self.__dict__.get(key)

    
        
class MessageGameAction(object):
    def __init__(self):
        self.actions = {}

    def set_action(self, agent_id:str, action: str):
        self.actions[agent_id] = action
    
    def to_json(self):
        return json.dumps(self.actions)

@unique
class GameEventEnum(Enum):
    GAMEREADY = 'GAMEREADY'
    GAMESTART = 'GAMESTART'
    GAMESTATE = 'GAMESTATE'
    GAMEEND = 'GAMEEND'
    GAMEOVER = 'GAMEOVER'
    GAMEFAIL = 'GAMEFAIL'

    @classmethod
    def has_member_key(cls, key):
        return key in cls.__members__

class GameEvent(object):
    def __init__(self, event_type: str, data: object):
        if not GameEventEnum.has_member_key(event_type):
            raise ValueError(f"event_type {event_type} is not a valid GameEventEnum")
        self.event_type = GameEventEnum(event_type)
        self.data = data

class Game(object,metaclass=abc.ABCMeta):
    states = ['init', 'ready', 'start', 'state', 'end', 'over']

    def __init__(self,server:str = "",match_id:str = "",token:str = ""):
        self.server = os.environ.get("GAME_SERVER",server)
        self.match_id = match_id
        self.token = os.environ.get("GAME_TOKEN",token)
        self.ws = None
        self.state = 'init'
        self.machine = None

        self.init_fsm()

        # 游戏相关
        self.current_role = None


    def init_fsm(self):
        self.machine = GraphMachine(model=self,states=Game.states, initial='init',after_state_change="_on_state_change")
        self.machine.add_transition(trigger=GameEventEnum.GAMEREADY.value,source='init',dest='ready', after='_on_game_ready')
        self.machine.add_transition(trigger=GameEventEnum.GAMESTART.value,source='ready',dest='start', after='_on_game_start')
        self.machine.add_transition(trigger=GameEventEnum.GAMESTATE.value,source='start',dest='state', after='_on_game_state')
        self.machine.add_transition(trigger=GameEventEnum.GAMESTATE.value,source='state',dest='state', after='_on_game_state')
        self.machine.add_transition(trigger=GameEventEnum.GAMEEND.value,source='state',dest='end', after='_on_game_end')
        self.machine.add_transition(trigger=GameEventEnum.GAMESTART.value,source='end',dest='start', after='_on_game_start')
        self.machine.add_transition(trigger=GameEventEnum.GAMEOVER.value,source='end',dest='over', after='_on_game_over')

        self.machine.add_transition(trigger=GameEventEnum.GAMEFAIL.value, source='*', dest='over', after='_on_game_fail')
    
    def draw(self):
        self.get_graph().draw("state.png",prog='dot')

    async def connect(self):
        async with websockets.connect(f"{self.server}/matches/{self.match_id}/join/{self.token}",ping_interval=None) as ws:
            # await ws.send(f"connect {self.match_id}")
            self.ws = ws
            await self.send_join()
            msg = await ws.recv()
            event = self.parse_resp(msg)
            #try except
            self.trigger(event.event_type.value, event)

            if self.state != 'ready':
                raise ValueError(f"Game is not ready, current state: {self.machine.state}")
            await self.loop()

    async def run(self):
        await self.connect()

    async def _run(self):
        await self.connect()

    def sync_run(self):
        asyncio.run(self.run())
        
    async def loop(self):
        while True:
            msg = await self.ws.recv()
            event = self.parse_resp(msg)
            try:
                self.trigger(event.event_type.value, event)
            except MachineError as e:
                logger.info(f"Invalid event: {event.event_type}, current state: {self.state}")
                raise e
            if self.is_over():
                logger.info("Game is over")
                break

    
    def parse_resp(self, msg) -> GameEvent:
        logger.info(f"Received: {msg}")
        rmsg = json.loads(msg)
        # check dict rmsg have keys 'type'
        if 'type' in rmsg.keys():
            rmsg_type = rmsg['type']
            if rmsg_type == 'start':
                return GameEvent("GAMESTART",rmsg)
            elif rmsg_type == 'state':
                return GameEvent("GAMESTATE",rmsg)
            elif rmsg_type == 'end':
                return GameEvent("GAMEEND",rmsg)
            elif rmsg_type == 'game_over':
                return GameEvent("GAMEOVER",rmsg)
            elif rmsg_type == 'game_fail':
                return GameEvent('GAMEFAIL',rmsg)
            elif rmsg_type == 'join_success':
                return GameEvent('GAMEREADY',rmsg)
            elif rmsg_type == 'join_failed':
                return GameEvent('GAMEFAIL',rmsg)
            else:
                raise ValueError(f"Unknown message type: {rmsg_type}")
        else:
            raise ValueError(f"Invalid message: {msg}")
        
    async def send_join(self):
        await self.ws.send(json.dumps({
            "type":"join",
            "player_id":self.token,
        }))
    
    async def send_action(self,steps,actions):
        logger.info(f"send:{actions},step:{steps}")
        await self.ws.send(json.dumps({
            "type":"action",
            "steps":steps,
            "actions":actions,
        }))
    
    async def send_ready(self):
        logger.info("send:ready")
        await self.ws.send(json.dumps({
            "code":"0",
            "message":"READY",
        }))
    
    def _on_state_change(self,_): logger.info(f"state changed to {self.state}")

    def _on_game_ready(self,data={}):
        logger.info("加入游戏成功...")

    def _on_game_start(self,data={}):
        logger.info("游戏开始...")
        logger.info(f'游戏状态:\r\n{json.dumps(data.data)}')
        self.on_game_start(data.data)
        asyncio.create_task(self.send_ready())

    def _on_game_state(self,data={}):
        logger.info("收到游戏更新状态...")
        logger.info(f'游戏状态:\r\n{json.dumps(data.data)}')
        # logger.info(f'游戏数据"{data.data}"')
        # 超时判断 cancel
        # _d = json.loads(data.data, object_hook=lambda d:SimpleNamespace(**d))
        _d = MessageGameState(data.data)
        asyncio.create_task(self.aon_game_state(_d))
       
    async def aon_game_state(self,data:MessageGameState):
        start_time = datetime.datetime.now()
        actions = self.on_game_state(data)
        end_time = datetime.datetime.now()
        time_interval = end_time - start_time
        logger.info(f"actions 计算时间:{time_interval}")
        # 记录开始时间结束时间，超过三秒则不发送
        if time_interval.total_seconds() > 3:
            logger.info(f"计算时间超过3s, reset all actions to 'STAY'")
            for k,_ in actions.items():
                actions[k] = "STAY"
        
        logger.info(f"发送游戏指令:{json.dumps(actions)}")

        await self.send_action(data.steps,actions)
    
    def _on_game_end(self,data={}):
        logger.info("单局游戏结束...")
        logger.info(f'本局比赛结果:\r\n{json.dumps(data.data)}')
        self.on_game_end(data.data)

    def _on_game_over(self,data={}):
        logger.info("游戏终止...")
        logger.info(f'游戏比赛结果:\r\n{json.dumps(data.data)}')
        self.on_game_over(data.data)
        exit(0)
    
    def _on_game_fail(self,data={}):
        logger.info("游戏出错，请咨询赛事方...")
        exit(1)

    @abc.abstractmethod
    def on_game_start(self,role):
        pass

    @abc.abstractmethod
    def on_game_state(self,data:MessageGameState) -> Dict[str,str]: #有返回值
        pass

    @abc.abstractmethod
    def on_game_end(self,data):
        pass

    @abc.abstractmethod
    def on_game_over(self,data):
        pass

